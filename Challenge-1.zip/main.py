"implement a recursive function to calculate the Factorial of given number"
def factorial(n):
    if(n==0 or n==1):
        return 1
    else:
        return n*factorial (n-1)
n=int(input("enter the n-value:"))
res=factorial(n) 
print("factorial of",n,"is",res)year = int(input("Enter the Year to be checked: "))
if (year % 400 == 0):
  print("%d is a Leap Year" % year)
elif (year % 100 == 0):
  print("%d is Not the Leap Year" % year)
elif (year % 4 == 0):
  print("%d is a Leap Year" % year)
else:
  print("%d is Not the Leap Year" % year)